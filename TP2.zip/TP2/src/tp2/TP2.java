
package tp2;

import java.util.Scanner;


public class TP2 {
    
    //11. Cálculo de descuento especial usando variable global.
    static double DESCUENTO = 0.1;


    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        // Estructuras Condicionales:
        
        // 1. Verificación de Año Bisiesto.
        
//        System.out.print("Ingrese un año: ");
//        int anio1 = Integer.parseInt(input.nextLine());
//        if ((anio1 % 4 == 0 && anio1 % 100 != 0) || (anio1 % 400 == 0)) {
//            System.out.println("El año " + anio1 + " es bisiesto.");            
//        } else {
//            System.out.println("El año " + anio1 + " no es bisiesto.");
//        }
        
        // 2. Determinar el Mayor de Tres números.
        
//        int num21;
//        int num22;
//        int num23;
//        
//        System.out.print("Ingrese el primer número: ");
//        num21 = Integer.parseInt(input.nextLine());
//        System.out.println("Ingrese el segundo número: ");
//        num22 = Integer.parseInt(input.nextLine());
//        System.out.println("Ingrese el tercer número: ");
//        num23 = Integer.parseInt(input.nextLine());
//        
//        
//        
//        if (num21 > num22 && num21 > num23) {
//            System.out.println("El mayor es " + num21);
//        } else if (num22 > num21 && num22 > num23) {
//            System.out.println("El mayor es " + num22);            
//        } else {
//            System.out.println("El mayor es " + num23);
//        }
        
        // 3. Clasificación de Edad.
        
//        int edad3;
//        
//        System.out.println("Ingrese su edad: ");
//        edad3 = Integer.parseInt(input.nextLine());
//        
//        if (edad3 < 12) {
//            System.out.println("Niño");
//        } else if (edad3 >= 12 && edad3 <= 17) {
//            System.out.println("Adolescente");
//        } else if (edad3 >= 18 && edad3 <= 59) {
//            System.out.println("Adulto");
//        } else if (edad3 >= 60) {
//            System.out.println("Adulto mayor");
//        }
          
        // 4. Calculadora de Descuento según categoría.
        
        
//        double precio41;
//        char categoria4;
//        String descuento41;
//        
//        System.out.println("Ingrese el precio del producto: ");
//        precio41 = Integer.parseInt(input.nextLine());
//        System.out.println("Ingrese la categoría del producto (A, B, C):");
//        categoria4 = input.nextLine().charAt(0);
//        
//        switch (categoria4) {
//            case 'A':
//            case 'a':
//                precio41 = (precio41 - precio41*0.1);
//                descuento41 = "10%";
//                System.out.println("Descuento aplicado: " + descuento41);
//                System.out.println("Precio final: " + precio41);
//                break;
//            case 'B':
//            case 'b':
//                precio41 = (precio41 - precio41*0.15);
//                descuento41 = "15%";
//                System.out.println("Descuento aplicado: " + descuento41);
//                System.out.println("Precio final: " + precio41);
//                break;
//            case 'C':
//            case 'c':
//                precio41 = (precio41 - precio41*0.2);
//                descuento41 = "20%";
//                System.out.println("Descuento aplicado: " + descuento41);
//                System.out.println("Precio final: " + precio41);
//                break;
//         }
            // Estructuras de Repetición:
            
            //5. Suma de Números Pares (while)
            
//            int num5 = 1;
//            int suma5 = 0;
//            
//            while (num5 != 0) {
//                System.out.println("Ingrese un número (0 para terminar): ");
//                num5 = Integer.parseInt(input.nextLine());
//                if (num5 % 2 == 0) {
//                    suma5 = suma5 + num5;
//                }     
//        }
//            System.out.println("La suma de los números pares es: " + suma5);

            //6. Contador de Positivos, Negativos y Ceros (for).
            
//            int num6;
//            int positivos6 = 0;
//            int negativos6 = 0;
//            int ceros6 = 0;
//            
//            for (int i = 1; i < 11; i++) {
//                System.out.println("Ingrese el número " + i);
//                num6 = Integer.parseInt(input.nextLine());
//                if (num6 > 0) {
//                    positivos6 += 1;
//                } else if (num6 < 0) {
//                    negativos6 += 1;
//                } else {
//                    ceros6 += 1;
//                }
//                
//                
//                
//        }
//            System.out.println("Resultados: ");
//            System.out.println("Positivos: " + positivos6);
//            System.out.println("Negativos: " + negativos6);
//            System.out.println("Ceros: " + ceros6);
            

            //7. Validación de Nota entre 0 y 10 (do-while).
            
//          int nota7;
//            
//            do {            
//                System.out.println("Ingrese una nota (0-10): ");
//                nota7 = Integer.parseInt(input.nextLine());
//        } while (nota7 > 10 || nota7 < 0);
//            System.out.println("Nota guardada correctamente.");
            
            //Funciones:
            
            //8. Cálculo del Precio Final con impuesto y descuento.
            
//            double precioFinal;
//            double precioBase;
//            double impuesto;
//            double descuento;
//            
//            System.out.println("Ingrese el precio base del producto: ");
//            precioBase = Double.parseDouble(input.nextLine());
//            System.out.println("Ingrese el impuesto en porcentaje (Ejemplo: 10 para 10%)");
//            impuesto = Double.parseDouble(input.nextLine());
//            System.out.println("Ingrese el descuento en porcentaje (Ejemplo: 5 para 5%)");
//            descuento = Double.parseDouble(input.nextLine());
//            
//            precioFinal = calcularPrecioFinal(precioBase, impuesto, descuento);
//            System.out.println("El precio final del producto es: " + precioFinal);

            //9. Composición de funciones para calcular costo de envío y total de compra.
            
//            double pesoPaquete, precioProducto, costoEnvio, totalPagar;
//            String zonaEnvio;
//            
//            System.out.print("Ingrese el precio del producto: ");
//            precioProducto = Double.parseDouble(input.nextLine());
//            System.out.print("Ingrese el peso del paquete en kg: ");
//            pesoPaquete = Double.parseDouble(input.nextLine());
//            System.out.print("Ingrese la zona de envío (Nacional/Internacional): ");
//            zonaEnvio = input.nextLine();
//            costoEnvio = calcularCostoEnvio(pesoPaquete, zonaEnvio);
//            System.out.println("El costo de envío es " + costoEnvio);
//            totalPagar = calcularTotalCompra(precioProducto, costoEnvio);
//            System.out.println("El total a pagar es: " + totalPagar);

//            System.out.println("El total a pagar es: " + totalPagar);
            
            //10. Actualización de stock a partir de venta y recepción de productos.
            
//            int stockActual, cantVendida, cantRecibida, nuevoStock; 
//            
//            System.out.print("Ingrese el stock actual del producto: ");
//            stockActual = Integer.parseInt(input.nextLine());
//            System.out.print("Ingrese la cantidad vendida: ");
//            cantVendida = Integer.parseInt(input.nextLine());
//            System.out.print("Ingrese la cantidad recibida: ");
//            cantRecibida = Integer.parseInt(input.nextLine());
//            nuevoStock = actualizarStock(stockActual, cantVendida, cantRecibida);
//            System.out.println("El nuevo stock del producto es: " + nuevoStock);
            
            //11. Cálculo de descuento especial usando variable global.
            //NO LO ENTENDÍ // NO LO ENTENDÍ // NO LO ENTENDÍ //
            
//            Double precioInicial, precioFinal, descuentoEspecial;
//            
//            
//            System.out.print("Ingrese el precio del producto: ");
//            precioInicial = Double.parseDouble(input.nextLine());
//            System.out.print("El descuento especial aplicado es: ");
//            descuentoEspecial = calcularDescuentoEspecial(precioInicial);
//            System.out.print("El precio final con descuento es: " + precioFinal);

            //Arrays y Recursividad:
            
            //12. Modificación de un array de precios y visualización de resultados.
            
//            Double[] precios = {150.50, 109.99, 200.99, 56.99, 21.50};
//            
//            System.out.println("Precios originales:");
//            for (int i = 0; i < precios.length; i++) {
//            System.out.println("Precio: " + precios[i]);
//        }
//            System.out.println("Precios modificados:");
//            precios[2] = 250.99;
//            for (int i = 0; i < precios.length; i++) {
//            System.out.println("Precio " + precios[i]);
//            
//        }

            //13. Impresión recursiva de arrays antes y después de modificar un elemento.
            
//            Double[] precios = {100.50, 150.50, 200.50};
//            recursivoPrecios(precios, 0);
            
            
    }
    
    //8. Cálculo del Precio Final con impuesto y descuento.
    
    /**
     * Retorna el precio del precio final considerando impuestos y descuentos.
     * @param precioBase El precio base del producto.
     * @param impuesto El impuesto a multiplicar.
     * @param descuento El descuento a multiplicar.
     * @return Precio Final a partir de precio base con impuestos y descuentos.
     */
    
    static double calcularPrecioFinal(double precioBase, double impuesto, double descuento) {
        double precioFinal = (precioBase + ((precioBase * impuesto)/100) - ((precioBase * descuento)/100));
        return precioFinal;
    }
    
    //9. Composición de funciones para calcular costo de envío y total de compra.
    
    /**
     * Retorna el precio del envío dependiendo si es Nacional o Internacional.
     * @param peso El peso del producto a comprar.
     * @param zona Si el transporte es Nacional o Internacional.
     * @return Peso X 5 si es Nacional // Peso X 10 si es Internacional.
     */
    static Double calcularCostoEnvio (double peso, String zona) {
        double costoEnvio = 0;
        
        if (zona.equalsIgnoreCase("nacional")) {
            costoEnvio = peso * 5;
        } else if (zona.equalsIgnoreCase("internacional")){
            costoEnvio = peso * 10;
        }
        return costoEnvio;        
    } 
   
    /**
     * Retorna el precio total sumando precio original + precio envío.
     * @param precioProducto El precio original del producto.
     * @param costoEnvio El precio del envío.
     * @return Precio original + precio del envío
     */
    
    static Double calcularTotalCompra (double precioProducto, double costoEnvio) {
       
        double totalCompra = precioProducto + costoEnvio;
        return totalCompra;
    }
    
    //10. Actualización de stock a partir de venta y recepción de productos.
   
    /**
     * Retorna el stock actual al restar lo vendido y sumar lo recibido al stock original.
     * @param stockActual El stock actual.
     * @param cantidadVendida La cantidad de stock vendida.
     * @param cantidadRecibida La cantidad de stock recibida.
     * @return 
     */
    static int actualizarStock (int stockActual, int cantidadVendida, int cantidadRecibida) {
        int nuevoStock = stockActual - cantidadVendida + cantidadRecibida;
        return nuevoStock;
    }
    
    
    //11. Cálculo de descuento especial usando variable global.
    
    /**
     * 
     * @param precio
     * @return 
     */
    static double calcularDescuentoEspecial (double precio) {
        double descuentoAplicado = DESCUENTO;
        double precioFinal = precio - (precio * descuentoAplicado);
        return precioFinal;
    }       
    
    //13. Impresión recursiva de arrays antes y después de modificar un elemento.
    static void recursivoPrecios(Double[] arreglo, int i) {
        if (i == arreglo.length) {
            return;
        } else {
            System.out.println("Precio[" + i + "] = " + arreglo[i]);
            recursivoPrecios(arreglo, i+1);
        }
        
    }
    
    
}